# Knockon static site (GitHub Pages via Actions)

Deploys automatically when you push to `main`.
